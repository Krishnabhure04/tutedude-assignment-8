# Django User Registration & Login Project
This project integrates user registration and login/logout functionality into a single Django app.
